import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Pricing from './components/Pricing';
import BlogList from './components/BlogList';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import { ViewState } from './types';
import { ArrowUp } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.HOME);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderView = () => {
    switch (currentView) {
      case ViewState.HOME:
        return (
          <>
            <Hero navigateToContact={() => setCurrentView(ViewState.CONTACT)} />
            <Features />
            <Pricing navigateToContact={() => setCurrentView(ViewState.CONTACT)} />
          </>
        );
      case ViewState.PRICING:
        return <Pricing navigateToContact={() => setCurrentView(ViewState.CONTACT)} />;
      case ViewState.BLOG:
        return <BlogList />;
      case ViewState.CONTACT:
        return <ContactForm />;
      default:
        return <Hero navigateToContact={() => setCurrentView(ViewState.CONTACT)} />;
    }
  };

  return (
    <div className="min-h-screen bg-eagle-dark text-slate-200 font-sans selection:bg-eagle-gold selection:text-eagle-dark flex flex-col">
      <Header currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-grow pt-20">
        {renderView()}
      </main>

      <Footer onViewChange={setCurrentView} />

      {/* Floating Action Button */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 bg-eagle-gold text-eagle-dark p-3 rounded-full shadow-lg z-50 transition-all duration-300 transform hover:scale-110 ${
          showScrollTop ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
        }`}
        aria-label="Scroll to top"
      >
        <ArrowUp size={24} strokeWidth={2.5} />
      </button>
    </div>
  );
};

export default App;