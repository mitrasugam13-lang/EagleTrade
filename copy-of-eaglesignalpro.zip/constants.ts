import { Plan, BlogPost, Signal, SignalType } from './types';

export const PRICING_PLANS: Plan[] = [
  {
    id: 'quarterly',
    name: 'Quarterly Access',
    price: '₹7,500',
    duration: '3 Months',
    features: [
      '3 Months Software Access',
      '2 Live Trainings Included',
      'Option Training - Basic',
      'Signal & Scanner Training'
    ]
  },
  {
    id: 'yearly',
    name: 'Yearly Access',
    price: '₹14,990',
    duration: '1 Year',
    recommended: true,
    features: [
      '1 Year Software Access',
      '3 Live Trainings Included',
      'Option Training - Intermediate',
      'Software, Signal & Scanner',
      'Intraday & Swing Training'
    ]
  },
  {
    id: 'lifetime',
    name: 'Lifetime Access',
    price: '₹24,990',
    duration: 'Lifetime',
    features: [
      'Lifetime Software Access',
      '4 Live Trainings Included',
      '5 Extra Premium Indicators',
      'Option Training - Advance',
      'Intraday & Swing Strategy',
      'Software Mastery Training'
    ]
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'Top 5 Strategies for BankNifty Intraday',
    excerpt: 'Master the volatility of the banking sector with these proven breakout strategies tailored for Indian markets.',
    date: 'Oct 20, 2023',
    category: 'Education',
    image: 'https://picsum.photos/400/250?random=1'
  },
  {
    id: '2',
    title: 'Understanding RBI Monetary Policy Impact',
    excerpt: 'How interest rate changes affect market trends and how you can position your portfolio for maximum gains.',
    date: 'Oct 18, 2023',
    category: 'Market News',
    image: 'https://picsum.photos/400/250?random=2'
  },
  {
    id: '3',
    title: 'Risk Management 101 for Option Buyers',
    excerpt: 'Why capital preservation is more important than profit. Learn the golden rules of stoploss.',
    date: 'Oct 15, 2023',
    category: 'Psychology',
    image: 'https://picsum.photos/400/250?random=3'
  }
];

export const PAST_SIGNALS: Signal[] = [
  {
    id: '1',
    date: '24 Oct 2023',
    script: 'BANKNIFTY 43500 CE',
    segment: 'Options',
    type: SignalType.BUY,
    entry: '340-350',
    exit: '480',
    pnl: 140,
    status: 'Target Hit'
  },
  {
    id: '2',
    date: '24 Oct 2023',
    script: 'BAJFINANCE',
    segment: 'Stock Options',
    type: SignalType.SELL,
    entry: '7450',
    exit: '7380',
    pnl: 70,
    status: 'Target Hit'
  },
  {
    id: '3',
    date: '23 Oct 2023',
    script: 'NIFTY 19400 PE',
    segment: 'Options',
    type: SignalType.BUY,
    entry: '110-115',
    exit: '185',
    pnl: 70,
    status: 'Target Hit'
  },
  {
    id: '4',
    date: '23 Oct 2023',
    script: 'RELIANCE',
    segment: 'Cash',
    type: SignalType.BUY,
    entry: '2280',
    exit: '2265',
    pnl: -15,
    status: 'Stoploss Hit'
  },
  {
    id: '5',
    date: '20 Oct 2023',
    script: 'NATURALGAS',
    segment: 'MCX',
    type: SignalType.BUY,
    entry: '245',
    exit: '258',
    pnl: 13,
    status: 'Target Hit'
  }
];