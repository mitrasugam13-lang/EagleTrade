import React from 'react';
import { PRICING_PLANS } from '../constants';
import { Check } from 'lucide-react';

interface PricingProps {
  navigateToContact: () => void;
}

const Pricing: React.FC<PricingProps> = ({ navigateToContact }) => {
  return (
    <section className="py-24 bg-gray-900/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            Transparent <span className="text-eagle-gold">Pricing</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Choose the plan that fits your trading style. No hidden fees, just pure value.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PRICING_PLANS.map((plan) => (
            <div 
              key={plan.id}
              className={`relative bg-eagle-card rounded-2xl overflow-hidden transition-all duration-300 flex flex-col ${
                plan.recommended 
                  ? 'border-2 border-eagle-gold shadow-[0_0_30px_rgba(255,215,0,0.15)] transform md:-translate-y-4 z-10' 
                  : 'border border-gray-800 hover:border-gray-600'
              }`}
            >
              {plan.recommended && (
                <div className="bg-eagle-gold text-eagle-dark text-center text-sm font-bold py-2 uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              
              <div className="p-8 flex flex-col h-full">
                <h3 className="text-2xl font-display font-bold text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-bold text-eagle-gold">{plan.price}</span>
                  <span className="text-gray-500 font-medium">/{plan.duration}</span>
                </div>

                <ul className="space-y-4 mb-8 flex-grow">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-gray-300">
                      <Check className="text-green-500 flex-shrink-0 mt-1" size={18} />
                      <span className="text-sm leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={navigateToContact}
                  className={`w-full py-4 rounded-lg font-bold transition-all duration-200 mt-auto ${
                    plan.recommended
                      ? 'bg-eagle-gold hover:bg-yellow-400 text-eagle-dark'
                      : 'bg-gray-800 hover:bg-gray-700 text-white'
                  }`}
                >
                  Choose Plan
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;