import React from 'react';
import { Target, Zap, Headphones, BarChart3, Lock, Smartphone } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Target className="w-8 h-8 text-eagle-gold" />,
      title: "High Accuracy",
      desc: "Our signals are backed by rigorous technical analysis and AI algorithms aiming for 90%+ accuracy."
    },
    {
      icon: <Zap className="w-8 h-8 text-eagle-accent" />,
      title: "Instant Alerts",
      desc: "Real-time notifications via WhatsApp and SMS ensure you never miss a profitable entry level."
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-purple-400" />,
      title: "Complete Analysis",
      desc: "We provide proper Entry, Stoploss, and multiple Targets for every single trade call."
    },
    {
      icon: <Headphones className="w-8 h-8 text-green-400" />,
      title: "Expert Support",
      desc: "Dedicated support team available during market hours to assist with your positions."
    },
    {
      icon: <Lock className="w-8 h-8 text-red-400" />,
      title: "Risk Management",
      desc: "We prioritize capital protection. All calls come with calculated risk-reward ratios."
    },
    {
      icon: <Smartphone className="w-8 h-8 text-blue-400" />,
      title: "Mobile Friendly",
      desc: "Access our platform and signals seamlessly on any device, anywhere, anytime."
    }
  ];

  return (
    <section className="py-24 bg-eagle-dark relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            Why Choose <span className="text-eagle-gold">EagleSignalPro</span>?
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We simplify trading for you. No complex charts, just clear actionable levels to help you grow your wealth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-eagle-card p-8 rounded-xl border border-gray-800 hover:border-eagle-gold/50 transition-all duration-300 hover:shadow-lg hover:shadow-eagle-gold/5 group"
            >
              <div className="bg-gray-800/50 w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-3 group-hover:text-eagle-gold transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;