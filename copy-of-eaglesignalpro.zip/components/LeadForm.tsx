import React, { useState } from 'react';
import { LeadFormData } from '../types';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

interface LeadFormProps {
  buttonText?: string;
}

const LeadForm: React.FC<LeadFormProps> = ({ buttonText = "Submit" }) => {
  const [formData, setFormData] = useState<LeadFormData>({
    name: '',
    phone: '',
    email: '',
    segment: 'NIFTY'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage(null);
    
    try {
      const response = await fetch("https://formspree.io/f/xeodwrlk", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setIsSuccess(true);
        setFormData({ name: '', phone: '', email: '', segment: 'NIFTY' });
        // Reset after showing success
        setTimeout(() => {
          setIsSuccess(false);
        }, 5000);
      } else {
        setErrorMessage("Something went wrong. Please try again.");
      }
    } catch (error) {
      setErrorMessage("Unable to submit form. Please check your connection.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center bg-green-900/20 rounded-lg border border-green-500/30 animate-fade-in">
        <CheckCircle className="text-green-500 mb-3" size={48} />
        <h3 className="text-xl font-bold text-white mb-1">Success!</h3>
        <p className="text-gray-300">Our team will contact you shortly.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {errorMessage && (
        <div className="flex items-center gap-2 p-3 bg-red-900/20 border border-red-500/30 rounded-lg text-red-200 text-sm animate-fade-in">
          <AlertCircle size={16} />
          {errorMessage}
        </div>
      )}

      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-1">Full Name</label>
        <input
          type="text"
          id="name"
          name="name"
          required
          value={formData.name}
          onChange={handleChange}
          className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-eagle-gold focus:ring-1 focus:ring-eagle-gold transition-colors"
          placeholder="Enter your name"
        />
      </div>

      <div>
        <label htmlFor="phone" className="block text-sm font-medium text-gray-400 mb-1">Phone Number</label>
        <div className="relative">
            <span className="absolute left-4 top-3 text-gray-500">+91</span>
            <input
            type="tel"
            id="phone"
            name="phone"
            required
            pattern="[0-9]{10}"
            value={formData.phone}
            onChange={handleChange}
            className="w-full bg-gray-900/50 border border-gray-700 rounded-lg pl-12 pr-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-eagle-gold focus:ring-1 focus:ring-eagle-gold transition-colors"
            placeholder="98765 43210"
            />
        </div>
      </div>

      <div>
        <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          required
          value={formData.email}
          onChange={handleChange}
          className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-eagle-gold focus:ring-1 focus:ring-eagle-gold transition-colors"
          placeholder="you@example.com"
        />
      </div>

      <div>
        <label htmlFor="segment" className="block text-sm font-medium text-gray-400 mb-1">Interested Segment</label>
        <select
          id="segment"
          name="segment"
          value={formData.segment}
          onChange={handleChange}
          className="w-full bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-eagle-gold focus:ring-1 focus:ring-eagle-gold transition-colors"
        >
          <option value="NIFTY">Nifty / BankNifty</option>
          <option value="STOCK">Stock Options</option>
          <option value="MCX">Commodity (MCX)</option>
          <option value="ALL">All Segments</option>
        </select>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-eagle-gold hover:bg-yellow-400 text-eagle-dark font-bold py-3 rounded-lg transition-all duration-200 mt-2 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="animate-spin" size={20} />
            Processing...
          </>
        ) : (
          buttonText
        )}
      </button>
    </form>
  );
};

export default LeadForm;