import React, { useState } from 'react';
import { ViewState } from '../types';
import { Twitter, Instagram, Facebook, Send, Loader2, Check } from 'lucide-react';

interface FooterProps {
  onViewChange: (view: ViewState) => void;
}

const Footer: React.FC<FooterProps> = ({ onViewChange }) => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'LOADING' | 'SUCCESS' | 'ERROR'>('IDLE');

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setStatus('LOADING');
    try {
      const response = await fetch("https://formspree.io/f/xeodwrlk", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, type: 'Newsletter Subscription' })
      });
      
      if (response.ok) {
        setStatus('SUCCESS');
        setEmail('');
        setTimeout(() => setStatus('IDLE'), 3000);
      } else {
        setStatus('ERROR');
      }
    } catch (error) {
      setStatus('ERROR');
    }
  };

  return (
    <footer className="bg-black text-gray-400 pt-16 border-t border-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand */}
          <div>
            <div className="text-2xl font-display font-bold text-white mb-4">
              Eagle<span className="text-eagle-gold">Signal</span>Pro
            </div>
            <p className="text-sm leading-relaxed mb-6">
              India's most trusted trading signal provider. We analyze, you capitalize. Join thousands of successful traders today.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-eagle-gold hover:text-eagle-dark transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-eagle-gold hover:text-eagle-dark transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-eagle-gold hover:text-eagle-dark transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center hover:bg-eagle-gold hover:text-eagle-dark transition-colors">
                <Send size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <button onClick={() => onViewChange(ViewState.HOME)} className="hover:text-eagle-gold transition-colors">Home</button>
              </li>
              <li>
                <button onClick={() => onViewChange(ViewState.PRICING)} className="hover:text-eagle-gold transition-colors">Pricing Plans</button>
              </li>
              <li>
                <button onClick={() => onViewChange(ViewState.BLOG)} className="hover:text-eagle-gold transition-colors">Market Blog</button>
              </li>
            </ul>
          </div>

          {/* Segments */}
          <div>
            <h4 className="text-white font-bold mb-6">Segments</h4>
            <ul className="space-y-3">
              <li className="hover:text-eagle-gold cursor-pointer transition-colors">Nifty Intraday</li>
              <li className="hover:text-eagle-gold cursor-pointer transition-colors">BankNifty Options</li>
              <li className="hover:text-eagle-gold cursor-pointer transition-colors">Stock Futures</li>
              <li className="hover:text-eagle-gold cursor-pointer transition-colors">MCX Commodities</li>
              <li className="hover:text-eagle-gold cursor-pointer transition-colors">BTST/STBT</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold mb-6">Newsletter</h4>
            <p className="text-sm mb-4">Subscribe to get daily market outlook.</p>
            <form onSubmit={handleSubscribe} className="flex flex-col gap-2">
              <div className="flex">
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email Address" 
                  required
                  disabled={status === 'LOADING' || status === 'SUCCESS'}
                  className="bg-gray-900 border border-gray-800 rounded-l-lg px-4 py-2 w-full focus:outline-none focus:border-eagle-gold text-sm text-white disabled:opacity-50"
                />
                <button 
                  type="submit" 
                  disabled={status === 'LOADING' || status === 'SUCCESS'}
                  className={`bg-eagle-gold text-eagle-dark px-4 py-2 rounded-r-lg font-bold hover:bg-yellow-400 transition-colors disabled:opacity-70 ${status === 'SUCCESS' ? 'bg-green-500 hover:bg-green-500' : ''}`}
                >
                  {status === 'LOADING' ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : status === 'SUCCESS' ? (
                    <Check size={16} />
                  ) : (
                    <Send size={16} />
                  )}
                </button>
              </div>
              {status === 'ERROR' && <p className="text-red-400 text-xs">Failed. Please try again.</p>}
              {status === 'SUCCESS' && <p className="text-green-400 text-xs">Subscribed successfully!</p>}
            </form>
          </div>
        </div>

        <div className="border-t border-gray-900 py-8 text-center text-xs text-gray-600 leading-relaxed">
          <p className="mb-4">
            <strong>Disclaimer:</strong> Trading in financial markets involves high risk. EagleSignalPro provides research based on technical analysis. We are not responsible for any financial losses. Please consult your financial advisor before trading. Past performance does not guarantee future results.
          </p>
          <p>
            &copy; {new Date().getFullYear()} EagleSignalPro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;