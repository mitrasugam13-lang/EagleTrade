import React from 'react';
import LeadForm from './LeadForm';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

const ContactForm: React.FC = () => {
  return (
    <section className="py-24 bg-eagle-dark">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            Get in <span className="text-eagle-gold">Touch</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Have questions about our premium plans? Reach out to us.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div className="flex-1 space-y-8">
            <div className="bg-eagle-card p-8 rounded-xl border border-gray-800">
               <h3 className="text-xl font-display font-bold text-white mb-6">Contact Information</h3>
               
               <div className="space-y-6">
                 <div className="flex items-start gap-4">
                   <div className="bg-gray-800 p-3 rounded-lg text-eagle-gold">
                     <MapPin size={24} />
                   </div>
                   <div>
                     <h4 className="text-white font-bold mb-1">Office Address</h4>
                     <p className="text-gray-400 text-sm leading-relaxed">
                       1204, Tech Park Plaza, <br/>
                       Mindspace, Malad West, <br/>
                       Mumbai, Maharashtra 400064
                     </p>
                   </div>
                 </div>

                 <div className="flex items-start gap-4">
                   <div className="bg-gray-800 p-3 rounded-lg text-eagle-gold">
                     <Phone size={24} />
                   </div>
                   <div>
                     <h4 className="text-white font-bold mb-1">Phone</h4>
                     <p className="text-gray-400 text-sm">+91 98765 43210</p>
                     <p className="text-gray-400 text-sm">+91 99887 76655</p>
                   </div>
                 </div>

                 <div className="flex items-start gap-4">
                   <div className="bg-gray-800 p-3 rounded-lg text-eagle-gold">
                     <Mail size={24} />
                   </div>
                   <div>
                     <h4 className="text-white font-bold mb-1">Email</h4>
                     <p className="text-gray-400 text-sm">support@eaglesignalpro.com</p>
                   </div>
                 </div>

                 <div className="flex items-start gap-4">
                   <div className="bg-gray-800 p-3 rounded-lg text-eagle-gold">
                     <Clock size={24} />
                   </div>
                   <div>
                     <h4 className="text-white font-bold mb-1">Working Hours</h4>
                     <p className="text-gray-400 text-sm">Mon - Fri: 9:00 AM - 6:00 PM</p>
                   </div>
                 </div>
               </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-gray-800 rounded-xl h-64 w-full flex items-center justify-center relative overflow-hidden">
                <img 
                    src="https://picsum.photos/600/300?grayscale&blur=2" 
                    alt="Map Location" 
                    className="absolute inset-0 w-full h-full object-cover opacity-50" 
                />
                <div className="relative z-10 bg-black/70 px-4 py-2 rounded text-white text-sm font-bold">
                    View on Google Maps
                </div>
            </div>
          </div>

          {/* Form */}
          <div className="flex-1">
            <div className="bg-eagle-card p-8 rounded-xl border border-gray-800 shadow-xl">
              <h3 className="text-2xl font-display font-bold text-white mb-2">Send Message</h3>
              <p className="text-gray-400 text-sm mb-6">Fill the form below and we will get back to you.</p>
              <LeadForm buttonText="Send Message" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;