import React from 'react';
import { PAST_SIGNALS } from '../constants';
import { SignalType } from '../types';

interface SignalHistoryProps {
  limit?: number;
  showHeader?: boolean;
}

const SignalHistory: React.FC<SignalHistoryProps> = ({ limit, showHeader }) => {
  const displaySignals = limit ? PAST_SIGNALS.slice(0, limit) : PAST_SIGNALS;

  return (
    <section className="py-24 bg-eagle-dark">
      <div className="container mx-auto px-4 md:px-6">
        {(showHeader || !limit) && (
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
              Past <span className="text-eagle-accent">Performance</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Transparency is our core value. Check our recent closed positions and their results.
            </p>
          </div>
        )}

        <div className="overflow-x-auto bg-eagle-card rounded-xl border border-gray-800 shadow-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-900/50 border-b border-gray-800 text-gray-400 text-xs uppercase tracking-wider">
                <th className="p-4 font-semibold">Date</th>
                <th className="p-4 font-semibold">Script</th>
                <th className="p-4 font-semibold">Type</th>
                <th className="p-4 font-semibold">Entry</th>
                <th className="p-4 font-semibold">Exit</th>
                <th className="p-4 font-semibold">Points Gained</th>
                <th className="p-4 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {displaySignals.map((signal) => (
                <tr key={signal.id} className="hover:bg-gray-800/30 transition-colors">
                  <td className="p-4 text-gray-300 font-medium whitespace-nowrap">{signal.date}</td>
                  <td className="p-4">
                    <div className="font-bold text-white">{signal.script}</div>
                    <div className="text-xs text-gray-500">{signal.segment}</div>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      signal.type === SignalType.BUY 
                        ? 'bg-green-500/10 text-green-500' 
                        : 'bg-red-500/10 text-red-500'
                    }`}>
                      {signal.type}
                    </span>
                  </td>
                  <td className="p-4 text-gray-300">{signal.entry}</td>
                  <td className="p-4 text-gray-300">{signal.exit}</td>
                  <td className={`p-4 font-bold ${signal.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {signal.pnl > 0 ? '+' : ''}{signal.pnl}
                  </td>
                  <td className="p-4 text-right">
                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                      signal.status === 'Target Hit' 
                        ? 'bg-green-500 text-white shadow-sm shadow-green-500/20' 
                        : 'bg-red-500 text-white'
                    }`}>
                      {signal.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default SignalHistory;