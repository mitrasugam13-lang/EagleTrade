import React, { useState } from 'react';
import { ViewState } from '../types';
import { Menu, X, TrendingUp } from 'lucide-react';

interface HeaderProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onViewChange }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'Home', view: ViewState.HOME },
    { label: 'Pricing', view: ViewState.PRICING },
    { label: 'Blogs', view: ViewState.BLOG },
    { label: 'Contact Us', view: ViewState.CONTACT },
  ];

  const handleNavClick = (view: ViewState) => {
    onViewChange(view);
    setIsMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-eagle-dark/95 backdrop-blur-md border-b border-gray-800">
      <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => handleNavClick(ViewState.HOME)}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-eagle-gold to-orange-500 rounded-lg flex items-center justify-center transform group-hover:rotate-6 transition-transform">
            <TrendingUp className="text-eagle-dark" size={24} />
          </div>
          <span className="text-2xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
            Eagle<span className="text-eagle-gold">Signal</span>Pro
          </span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavClick(item.view)}
              className={`text-sm font-medium tracking-wide transition-colors duration-200 uppercase font-display ${
                currentView === item.view 
                  ? 'text-eagle-gold' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button 
             onClick={() => handleNavClick(ViewState.CONTACT)}
             className="bg-eagle-gold hover:bg-yellow-400 text-eagle-dark font-bold py-2 px-6 rounded-full transition-all duration-300 transform hover:-translate-y-0.5 shadow-lg shadow-yellow-500/20"
          >
            Get Started
          </button>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-300"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Nav Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 right-0 bg-eagle-dark border-b border-gray-800 p-4 flex flex-col gap-4 shadow-2xl animate-fade-in">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavClick(item.view)}
              className={`text-left py-3 px-4 rounded-lg text-lg font-medium font-display ${
                currentView === item.view 
                  ? 'bg-gray-800 text-eagle-gold' 
                  : 'text-gray-300 hover:bg-gray-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
};

export default Header;