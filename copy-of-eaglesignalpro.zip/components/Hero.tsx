import React from 'react';
import LeadForm from './LeadForm';
import { ShieldCheck, Headphones, Users } from 'lucide-react';

interface HeroProps {
  navigateToContact: () => void;
}

const Hero: React.FC<HeroProps> = ({ navigateToContact }) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-24 md:pt-20 md:pb-32">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-eagle-gold/10 rounded-full blur-3xl"></div>
        <div className="absolute top-40 -left-20 w-72 h-72 bg-eagle-accent/10 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left animate-slide-up">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-eagle-card border border-gray-700 text-eagle-gold text-xs font-bold uppercase tracking-wider mb-6">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              Live Market Updates
            </div>
            
            <h1 className="text-4xl md:text-6xl font-display font-bold leading-tight mb-6 text-white">
              Master the <span className="text-transparent bg-clip-text bg-gradient-to-r from-eagle-gold to-orange-400">Indian Markets</span> with Precision
            </h1>
            
            <p className="text-lg md:text-xl text-gray-400 mb-8 max-w-2xl mx-auto lg:mx-0 font-light">
              Get highly accurate Intraday and Positional signals for Nifty, BankNifty, and Stock Options. Powered by advanced technical analysis and AI.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-12">
              <button 
                onClick={navigateToContact}
                className="w-full sm:w-auto px-8 py-4 bg-eagle-gold text-eagle-dark font-bold rounded-lg hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(255,215,0,0.3)]"
              >
                Join Free Telegram
              </button>
              <button 
                 onClick={navigateToContact}
                 className="w-full sm:w-auto px-8 py-4 bg-transparent border border-gray-600 hover:border-eagle-gold hover:text-eagle-gold text-white font-semibold rounded-lg transition-all"
              >
                View Plans
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 border-t border-gray-800 pt-8">
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-1 text-eagle-accent">
                  <ShieldCheck size={20} />
                  <span className="font-bold text-2xl">85%</span>
                </div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">Accuracy</p>
              </div>
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-1 text-eagle-accent">
                  <Users size={20} />
                  <span className="font-bold text-2xl">5k+</span>
                </div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">Active Traders</p>
              </div>
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-2 mb-1 text-eagle-accent">
                  <Headphones size={20} />
                  <span className="font-bold text-2xl">Live</span>
                </div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">Market Support</p>
              </div>
            </div>
          </div>

          {/* Form Card */}
          <div className="w-full max-w-md animate-fade-in relative">
            <div className="absolute inset-0 bg-gradient-to-b from-eagle-gold to-transparent opacity-20 blur-xl rounded-2xl transform rotate-3 scale-105"></div>
            <div className="relative bg-eagle-card border border-gray-700 p-8 rounded-2xl shadow-2xl">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-display font-bold text-white mb-2">Get Free Trial</h3>
                <p className="text-sm text-gray-400">Register for free live demo.</p>
              </div>
              <LeadForm buttonText="Start Free Trial" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;