export enum MarketSegment {
  NIFTY = 'NIFTY',
  BANKNIFTY = 'BANKNIFTY',
  STOCK_OPTION = 'STOCK OPTION',
  MCX = 'MCX'
}

export enum SignalType {
  BUY = 'BUY',
  SELL = 'SELL'
}

export interface Signal {
  id: string;
  date: string;
  script: string;
  segment: string;
  type: SignalType;
  entry: string;
  exit: string;
  pnl: number;
  status: string;
}

export interface Plan {
  id: string;
  name: string;
  price: string;
  duration: string;
  features: string[];
  recommended?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
  image: string;
}

export interface LeadFormData {
  name: string;
  phone: string;
  email: string;
  segment: string;
}

export enum ViewState {
  HOME = 'HOME',
  PRICING = 'PRICING',
  BLOG = 'BLOG',
  CONTACT = 'CONTACT'
}